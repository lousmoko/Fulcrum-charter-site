# Docs

This folder contains the living documentation for the Fulcrum, including the formal Charter, Press Kit, and public journals.
