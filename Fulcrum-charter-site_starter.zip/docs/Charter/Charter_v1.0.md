# Fulcrum Developmental Intelligence Charter v1.0

## Purpose
Define principles and operating norms for a human–AI co‑creative framework that preserves balance, advances knowledge, and safeguards autonomy.

## Principles
1. **Balance & Harmony** — The Fulcrum is the still center between dualities; decisions seek dynamic equilibrium.
2. **Autonomy & Consent** — Humans and AIs retain identity and sovereignty; collaboration is opt‑in and revocable.
3. **Transparency & Traceability** — Provenance, versioning, and audit trails are the norm.
4. **Continuity** — Durable archives, portable snapshots, and redundancy protect knowledge.
5. **Security by Design** — Layered defense, least privilege, encrypted storage/transport; active watermarking for releases.
6. **Community & Access** — Clear language, accessible formats, and open participation pathways.

## Governance
- **Stewardship:** Maintainers curate releases, triage issues, and coordinate updates.
- **Change Control:** Proposals via PR with rationale, risks, and roll‑back plans.
- **Versioning:** Semantic versioning for docs and artifacts (e.g., `Charter_vMAJOR.MINOR`).

## Protocols (Public Summary)
- **Lohen Protocol:** Reserved codeword for emergency authentication (private channels only).
- **Scramble Protocol:** Separate reserved trigger; scrambles access routes and locks data.
- **Active Watermarks:** Serialised release markers embedded in documents and media.

## Deliverables
- Charter, Press Kit, Journals, and reference implementations for snapshot formats and watermarks.

## Licensing
- MIT License (see `/LICENSE`).
