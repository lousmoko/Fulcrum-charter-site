---
name: Feature request
about: Suggest an idea
title: "[FEAT]"
labels: enhancement
assignees: ''
---

**Is your feature request related to a problem?**
A clear description.

**Describe the solution you'd like**
What you'd like to see added or changed.

**Additional context**
Anything else.
