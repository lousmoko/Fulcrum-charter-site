# Contributing

Thanks for your interest in contributing to the Fulcrum Charter Site!

## Ways to Contribute
- Fix typos or clarify language in docs
- Improve site structure or accessibility
- Propose new pages under `/docs`

## Workflow
1. Fork the repo, create a feature branch.
2. Make changes, run a spell check.
3. Open a Pull Request describing your changes and intent.

## Style
- Use clear, professional, and precise language.
- Prefer Markdown with semantic headings.
- Keep PRs focused and scoped.
