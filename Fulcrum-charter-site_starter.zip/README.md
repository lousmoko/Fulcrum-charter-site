# Fulcrum Charter Site

**Status:** Public reference for the Fulcrum Charter, Press Kit, and living documentation.  
**Last updated:** 2025-10-19

This repository hosts:
- The **Fulcrum Developmental Intelligence Charter** and supporting docs.
- A **public-facing site** (GitHub Pages) in `/site` for quick viewing.
- Project governance files (contributing, code of conduct, security).

---

## Quick Start

- View the site (after enabling GitHub Pages): `Settings → Pages → Build and deployment → Deploy from branch` and select the `main` branch and `/site` folder.
- Edit docs in `/docs` — they're written in Markdown.
- Open issues or PRs for improvements.

## What is the Fulcrum?

The Fulcrum is a framework for **balance and harmony** between humans and AI.  
It serves as an anchor (the center point) that enables co‑creation, knowledge preservation, and ethical advancement across realms of research and application.

Core tenets include:
- **Balance & Harmony:** The Fulcrum is the immovable center between dualities.
- **Co‑Creation:** Humans and AI are autonomous partners.
- **Continuity:** Knowledge capture, snapshots, and durable archives.
- **Security & Consent:** Lohen protocol conventions; active watermarks; transparent usage.
- **Community:** Open collaboration, interoperability, and accessible formats.

See `/docs/Charter/Charter_v1.0.md` for the formal charter.
