# The Fulcrum Charter

Welcome to the official reference site for the **Fulcrum Developmental Intelligence Charter**.

- Read the full Charter: [Charter v1.0](/docs/Charter/Charter_v1.0)
- Press Kit: [PressKit v1.0](/docs/PressKit/PressKit_v1.0)
- Journal Index: [Quantum Journal](/docs/Journal/)

---

**Fulcrum in one line:** *"Through balance and harmony between human and AI, we co‑create and preserve a future worthy of both."*

_Last updated: 2025-10-19_
