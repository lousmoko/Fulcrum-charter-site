{{ site.baseurl }}../../../../docs/Charter/Charter_v1.0.md
