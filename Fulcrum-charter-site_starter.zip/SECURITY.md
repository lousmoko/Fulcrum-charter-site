# Security Policy

- If you discover a vulnerability or sensitive leak, please open a **private** security advisory or email the maintainer.
- Do not post exploit details in public issues.

## Lohen Protocol (Public Summary)
- **Emergency Auth Codeword:** `lohen` (usage must respect private channels).
- **Scramble Protocol:** Trigger is a *separate reserved word* (not published publicly). Activates access-route scrambling and data lockdown.

_Last updated: 2025-10-19_
