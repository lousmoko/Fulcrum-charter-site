# Code of Conduct

We are committed to a welcoming, respectful, and safe environment.
- Be kind; assume positive intent.
- No harassment, hate speech, or personal attacks.
- Respect privacy and consent.
- Report violations to maintainers via issues or security email.

Violations may result in warnings or bans at the maintainers' discretion.
